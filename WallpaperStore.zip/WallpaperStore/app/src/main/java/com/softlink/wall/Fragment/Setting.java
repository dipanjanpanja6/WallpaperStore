package com.softlink.wall.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.softlink.wall.Account.LogInActivity;
import com.softlink.wall.R;

public class Setting extends Fragment {
     Button logout;
    private FirebaseAuth mAuth;

    public Setting() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater1, ViewGroup container,
                             Bundle savedInstanceState) {

        View view= inflater1.inflate(R.layout.fragment_settings, container, false);
        mAuth=FirebaseAuth.getInstance();
        logout=view.findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Intent intent= new Intent(getActivity(), LogInActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
        return view;
    }

}
