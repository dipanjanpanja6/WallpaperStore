package com.softlink.wall.Fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.pd.chocobar.ChocoBar;
import com.softlink.wall.Account.LogInActivity;
import com.softlink.wall.CatViewActivity;
import com.softlink.wall.FullscreenActivity;
import com.softlink.wall.Model_Holder.ImageViewHolder;
import com.softlink.wall.Model_Holder.Images;
import com.softlink.wall.R;
import com.squareup.picasso.Picasso;


/**
 * A simple {@link Fragment} subclass.
 */

public class HomeFragment extends Fragment {

    public FirebaseAuth mAuth;


    FirebaseRecyclerOptions<Images> options;
    FirebaseRecyclerAdapter<Images, ImageViewHolder> adapter;

    DatabaseReference Data;
    RecyclerView recyclerView;


    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_home, container, false);

        mAuth = FirebaseAuth.getInstance();
        Data = FirebaseDatabase.getInstance().getReference().child("wallpaper");
       // Data.keepSynced(true);
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null)
        {
            Intent intent = new Intent(getActivity(), LogInActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }


        options = new FirebaseRecyclerOptions.Builder<Images>()
                .setQuery(Data, Images.class).build();

        adapter = new FirebaseRecyclerAdapter<Images, ImageViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull ImageViewHolder holder, int position, @NonNull final Images model) {
                //Picasso.get().load(model.getLink()).placeholder(R.drawable.ic_wallpaper_black_24dp).into(holder.imageView);
                Glide.with(getContext()).load(model.getLink()).placeholder(R.drawable.ic_sync_black_24dp).into(holder.imageView);
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(getActivity(), FullscreenActivity.class);
                        intent.putExtra("link", model.getLink());
                        startActivity(intent);
                    }
                });
            }

            @NonNull
            @Override
            public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view = LayoutInflater.from(getContext()).inflate(R.layout.imageview, viewGroup, false);


                return new ImageViewHolder(view);
            }
        };

        if (adapter ==null)
        {
           // Toast.makeText(getContext(), "Wait...", Toast.LENGTH_SHORT).show();
            ChocoBar.builder().setText("Wait...").orange().show();
        }
        GridLayoutManager LayoutManager = new GridLayoutManager(getContext(), 3);
        recyclerView.setLayoutManager(LayoutManager);
        adapter.startListening();
        recyclerView.setAdapter(adapter);
        return view;
    }

}
