package com.softlink.wall.Model_Holder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.softlink.wall.R;

public class LinkViewHolder extends RecyclerView.ViewHolder {

    public ImageView imageView;
    public LinkViewHolder(@NonNull View itemView) {
        super(itemView);

        imageView = itemView.findViewById(R.id.imageView);
    }
}
