package com.softlink.wall;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.content.FileProvider;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.Request;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomViewTarget;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.SizeReadyCallback;
import com.bumptech.glide.request.target.ThumbnailImageViewTarget;
import com.bumptech.glide.request.transition.Transition;
import com.pd.chocobar.ChocoBar;
import com.softlink.wall.R;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class FullscreenActivity extends AppCompatActivity {
    private ImageView imageView;
    private LinearLayout Set,dwnld,fav,shere;
    String link;

    private static final int WRITE_EXTERNAL_STORAGE_CODE = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_fullscreen);
        link = getIntent().getExtras().get("link").toString();
        imageView = findViewById(R.id.full_image);
        Picasso.get().load(link).into(imageView);
        //Glide.with(this).load(link).into(imageView);


        Set = findViewById(R.id.set_wallpaper);
        dwnld = findViewById(R.id.download_wallpaper);
        fav = findViewById(R.id.favWall);
        shere = findViewById(R.id.share_wallpaper);



        

        shere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(FullscreenActivity.this, "Getting things ready....", Toast.LENGTH_SHORT).show();

                shareimage();
            }
        });

        Set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setwallpaper();
            }
        });

        dwnld.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                            PackageManager.PERMISSION_DENIED) {
                        String[] permission = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                                                                        //show popup to grant permission
                        requestPermissions(permission, WRITE_EXTERNAL_STORAGE_CODE);
                    } else {
                                                                        //permission already granted, save image
                        saveImage();
                    }
                } else {
                                                                        //System os is < marshmallow, save image
                    saveImage();
                }
            }
        });
    }




    private void setwallpaper() {


Picasso.get().load(link).into(new Target() {
    @Override
    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
        WallpaperManager myWallpaperManager;
        myWallpaperManager = WallpaperManager.getInstance(getApplicationContext());
        try {
        myWallpaperManager.setBitmap(bitmap);
            ChocoBar.builder().setActivity(FullscreenActivity.this)
                    .setText("Wallpaper Set")
                    .setDuration(ChocoBar.LENGTH_SHORT)
                    .green()
                    .show();
    } catch (IOException e) {
            ChocoBar.builder().setActivity(FullscreenActivity.this)
                    .setText("Error setting wallpaper")
                    .setDuration(ChocoBar.LENGTH_SHORT)
                    .red()
                    .show();
    }
    }

    @Override
    public void onBitmapFailed(Exception e, Drawable errorDrawable) {
        ChocoBar.builder().setActivity(FullscreenActivity.this)
                .setText("Download failed")
                .setDuration(ChocoBar.LENGTH_SHORT)
                .red()
                .show();
    }

    @Override
    public void onPrepareLoad(Drawable placeHolderDrawable) {
        ChocoBar.builder().setActivity(FullscreenActivity.this)
                .setText("Downloading...")
                .setDuration(ChocoBar.LENGTH_SHORT)
                .orange()
                .show();

    }
        });

    }

    private void shareimage() {
Picasso.get().load(link).into(new Target() {
    @Override
    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
        File filepath = Environment.getExternalStorageDirectory();
        File dir = new File(filepath.getAbsolutePath() + "/Wallpaper Store/");
        dir.mkdirs();
        File file = new File(dir, "WallpaperStoreShare"+ System.currentTimeMillis()+".png");
        try {
            OutputStream output;
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("image/png");
            output = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, output);
            output.flush();
            output.close();
            Uri uri =FileProvider.getUriForFile(FullscreenActivity.this, "com.codepath.fileprovider", file);
            share.putExtra(Intent.EXTRA_STREAM, uri);
            startActivity(Intent.createChooser(share, "Wallpaper Store Image share"));

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public void onBitmapFailed(Exception e, Drawable errorDrawable) {
        ChocoBar.builder().setActivity(FullscreenActivity.this)
                .setText("Preparing failed")
                .setDuration(ChocoBar.LENGTH_SHORT)
                .red()
                .show();
    }

    @Override
    public void onPrepareLoad(Drawable placeHolderDrawable) {
        ChocoBar.builder().setActivity(FullscreenActivity.this)
                .setText("Prepared for Share")
                .setDuration(ChocoBar.LENGTH_SHORT)
                .orange()
                .show();

    }
});

    }


    private void saveImage() {
        Picasso.get().load(link).into(new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss",
                        Locale.getDefault()).format(System.currentTimeMillis());
                File path = Environment.getExternalStorageDirectory();
                File dir = new File(path + "/Wallpaper Store/");
                dir.mkdirs();
                String imageName = timeStamp + ".jpg";
                File file = new File(dir, imageName);
                OutputStream out;
                try {
                    out = new FileOutputStream(file);
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                    out.flush();
                    out.close();

                    ChocoBar.builder().setActivity(FullscreenActivity.this)
                            .setText(imageName + " saved to" + dir)
                            .setDuration(ChocoBar.LENGTH_SHORT)
                            .green()
                            .show();
                } catch (Exception e) {
                    ChocoBar.builder().setActivity(FullscreenActivity.this)
                            .setText(e.getMessage())
                            .setDuration(ChocoBar.LENGTH_SHORT).red().show();
                }
            }

            @Override
            public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                ChocoBar.builder().setActivity(FullscreenActivity.this)
                        .setText("Download failed")
                        .setDuration(ChocoBar.LENGTH_SHORT)
                        .red()
                        .show();
            }

            @Override
            public void onPrepareLoad(Drawable placeHolderDrawable) {
                ChocoBar.builder().setActivity(FullscreenActivity.this)
                        .setText("Downloading")
                        .setDuration(ChocoBar.LENGTH_SHORT)
                        .orange()
                        .show();
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case WRITE_EXTERNAL_STORAGE_CODE: {
                //if request code is cancelled the result arrays are empty
                if (grantResults.length > 0 && grantResults[0] ==
                        PackageManager.PERMISSION_GRANTED) {
                    //permission is granted, save image
                    saveImage();
                } else {
                    //permission denied
                    ChocoBar.builder().setActivity(FullscreenActivity.this)
                            .setText("enable permission to save image")
                            .setDuration(ChocoBar.LENGTH_SHORT)
                            .orange()
                            .show();
                }
            }
        }
    }


}
