package com.softlink.wall.Model_Holder;

public class Link {
    String link;

    public Link(String link) {
        this.link = link;
    }

    public Link() {
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
