package com.softlink.wall;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.softlink.wall.Model_Holder.Link;
import com.softlink.wall.Model_Holder.LinkViewHolder;
import com.squareup.picasso.Picasso;

public class CatViewActivity extends AppCompatActivity {

    private DatabaseReference DataRaf;
    private RecyclerView recyclerView;

    FirebaseRecyclerOptions<Link> options;
    FirebaseRecyclerAdapter<Link, LinkViewHolder> adapter;
    String key;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cat_view);
        recyclerView = findViewById(R.id.cat_full_recycler_view);
        recyclerView.setHasFixedSize(true);

        key = getIntent().getExtras().get("name").toString();
        DataRaf = FirebaseDatabase.getInstance().getReference().child("catagory");

        options = new FirebaseRecyclerOptions.Builder<Link>()
                .setQuery(DataRaf.child(key), Link.class)
                .build();

        adapter = new FirebaseRecyclerAdapter<Link, LinkViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull LinkViewHolder holder, int position, @NonNull final Link model) {
                //Picasso.get().load(model.getLink()).placeholder(R.drawable.ic_wallpaper_black_24dp).into(holder.imageView);
                Glide.with(getApplicationContext()).load(model.getLink()).placeholder(R.drawable.ic_sync_black_24dp).into(holder.imageView);
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(CatViewActivity.this, FullscreenActivity.class);
                        intent.putExtra("link", model.getLink());
                        startActivity(intent);
                    }
                });
            }

            @NonNull
            @Override
            public LinkViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.imageview, viewGroup, false);

                return new LinkViewHolder(view);

            }
        };

        GridLayoutManager LayoutManager = new GridLayoutManager(getApplicationContext(), 2);
        recyclerView.setLayoutManager(LayoutManager);
        adapter.startListening();
        recyclerView.setAdapter(adapter);
    }
}
