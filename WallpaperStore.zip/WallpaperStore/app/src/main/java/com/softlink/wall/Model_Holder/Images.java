package com.softlink.wall.Model_Holder;

public class Images {
    String link;

    public Images(String link) {
        this.link = link;
    }

    public Images() {
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
