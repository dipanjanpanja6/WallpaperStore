package com.softlink.wall;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.view.MenuItem;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.softlink.wall.Account.LogInActivity;
import com.softlink.wall.Fragment.CatagoryFragment;
import com.softlink.wall.Fragment.FaveFragment;
import com.softlink.wall.Fragment.HomeFragment;
import com.softlink.wall.Fragment.Setting;

public class MainActivity extends AppCompatActivity {

    CatagoryFragment catagoryFragment;
    FaveFragment faveFragment;
    HomeFragment homeFragment;
    Setting settingsFragment;


    public BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    getFragment(homeFragment);
                    return true;
                case R.id.navigation_favorite:
                    getFragment(faveFragment);
                    return true;
                case R.id.navigation_settings:
                    getFragment(settingsFragment);

                case R.id.navigation_catagory:
                    getFragment(catagoryFragment);
                    return true;
            }
            return false;
        }
    };

    private void getFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction=getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.framLayout,fragment);
        fragmentTransaction.commit();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);

        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null)
        {
            Intent intent = new Intent(MainActivity.this, LogInActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        catagoryFragment = new CatagoryFragment();
        homeFragment = new HomeFragment();
        faveFragment = new FaveFragment();
        settingsFragment = new Setting();

        getSupportFragmentManager().beginTransaction().replace(R.id.framLayout, new HomeFragment()).commit();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.framLayout, new Setting())
                .commit();
    }

}
